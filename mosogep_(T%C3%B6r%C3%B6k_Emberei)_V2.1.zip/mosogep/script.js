
let cart = parseInt(localStorage.getItem("cart")) || 0;
function updateCartDisplay() {
  const cartElement = document.querySelector("#cart-count");
  if (cartElement) {
    cartElement.innerText = cart;
  }
}

window.addEventListener("DOMContentLoaded", updateCartDisplay);

function addToCart(product) {
  cart++;
  localStorage.setItem("cart", cart);
  document.querySelector(".cart-box").innerText = "🛒 " + cart;
}


const elements = document.querySelectorAll(".hidden");

window.addEventListener("scroll", () => {
  elements.forEach(el => {
    const rect = el.getBoundingClientRect();
    if (rect.top < window.innerHeight - 50) {
      el.classList.add("show");
    }
  });
});

function goToProduct(url) {
  window.location.href = url;
}
