
const CART_KEY = "cartItems";
const productCatalog = {
  "Samsung WW80": { price: 129990 },
  "LG TurboWash": { price: 119990 },
  "Bosch Serie 4": { price: 139990 },
  "Samsung EcoBubble": { price: 134990 },
  "LG Inverter": { price: 109990 },
  "Bosch Maxx 7": { price: 149990 }
};

function loadCartItems() {
  return JSON.parse(localStorage.getItem(CART_KEY)) || [];
}

function saveCartItems(items) {
  localStorage.setItem(CART_KEY, JSON.stringify(items));
}

function formatPrice(value) {
  return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ") + " Ft";
}

function getCartCount() {
  return loadCartItems().reduce((sum, item) => sum + item.quantity, 0);
}

function updateCartDisplay() {
  const count = getCartCount();
  const cartCountElement = document.querySelector("#cart-count");
  if (cartCountElement) {
    cartCountElement.innerText = count;
  }

  const cartBox = document.querySelector(".cart-box");
  if (cartBox && !cartCountElement) {
    cartBox.innerText = `🛒 ${count}`;
  }
}

function addToCart(productName) {
  const items = loadCartItems();
  const product = productCatalog[productName] || { price: 0 };
  const existing = items.find(item => item.name === productName);
  if (existing) {
    existing.quantity += 1;
  } else {
    items.push({ name: productName, price: product.price, quantity: 1 });
  }
  saveCartItems(items);
  updateCartDisplay();
  showCartToast(`${productName} sikeresen hozzáadva a kosárhoz.`);
}

function showCartToast(message) {
  let toast = document.querySelector(".cart-toast");
  if (!toast) {
    toast = document.createElement("div");
    toast.className = "cart-toast";
    document.body.appendChild(toast);
  }
  toast.innerText = message;
  toast.classList.add("visible");
  setTimeout(() => toast.classList.remove("visible"), 2500);
}

function goToProduct(url) {
  window.location.href = url;
}

function showAuthSection(section) {
  const loginCard = document.querySelector('#login-card');
  const registerCard = document.querySelector('#register-card');
  if (!loginCard || !registerCard) return;

  if (section === 'register') {
    loginCard.classList.add('hidden-auth');
    registerCard.classList.remove('hidden-auth');
  } else {
    registerCard.classList.add('hidden-auth');
    loginCard.classList.remove('hidden-auth');
  }
}

function setupAuthToggle() {
  const loginLink = document.querySelector('#show-login');
  const registerLink = document.querySelector('#show-register');

  if (loginLink) {
    loginLink.addEventListener('click', (e) => {
      e.preventDefault();
      showAuthSection('login');
      window.location.hash = 'login';
    });
  }

  if (registerLink) {
    registerLink.addEventListener('click', (e) => {
      e.preventDefault();
      showAuthSection('register');
      window.location.hash = 'register';
    });
  }

  const handleHash = () => {
    const hash = window.location.hash.replace('#', '').toLowerCase();
    if (hash === 'register') {
      showAuthSection('register');
    } else {
      showAuthSection('login');
    }
  };

  window.addEventListener('hashchange', handleHash);
  handleHash();
}

function renderCartPage() {
  const container = document.querySelector("#cart-items");
  const emptyMessage = document.querySelector("#cart-empty");
  const content = document.querySelector("#cart-content");
  if (!container || !emptyMessage || !content) {
    return;
  }

  const items = loadCartItems();
  if (items.length === 0) {
    emptyMessage.style.display = "block";
    content.style.display = "none";
    return;
  }

  emptyMessage.style.display = "none";
  content.style.display = "block";
  container.innerHTML = "";

  let total = 0;
  items.forEach(item => {
    total += item.price * item.quantity;

    const row = document.createElement("div");
    row.className = "cart-row";
    row.innerHTML = `
      <div class="cart-item-info">
        <div class="cart-item-name">${item.name}</div>
        <div class="cart-item-price">${formatPrice(item.price)}</div>
      </div>
      <div class="quantity-controls">
        <button class="qty-btn" type="button" onclick="updateCartItem('${item.name}', ${item.quantity - 1})">−</button>
        <span class="qty-value">${item.quantity}</span>
        <button class="qty-btn" type="button" onclick="updateCartItem('${item.name}', ${item.quantity + 1})">+</button>
      </div>
      <div class="cart-item-subtotal">${formatPrice(item.price * item.quantity)}</div>
      <button class="remove-btn" type="button" onclick="removeCartItem('${item.name}')">Törlés</button>
    `;
    container.appendChild(row);
  });

  const totalElement = document.querySelector("#cart-total");
  if (totalElement) {
    totalElement.innerText = formatPrice(total);
  }
}

function updateCartItem(productName, quantity) {
  const items = loadCartItems();
  const item = items.find(row => row.name === productName);
  if (!item) {
    return;
  }

  item.quantity = quantity;
  if (item.quantity <= 0) {
    saveCartItems(items.filter(row => row.name !== productName));
  } else {
    saveCartItems(items);
  }
  updateCartDisplay();
  renderCartPage();
}

function removeCartItem(productName) {
  saveCartItems(loadCartItems().filter(item => item.name !== productName));
  updateCartDisplay();
  renderCartPage();
}

function clearCart() {
  if (confirm("Biztosan törlöd a kosarat?")) {
    saveCartItems([]);
    updateCartDisplay();
    renderCartPage();
  }
}

function checkout() {
  const items = loadCartItems();
  if (items.length === 0) {
    alert("A kosarad üres.");
    return;
  }
  alert("Köszönjük! A rendelés folyamata még nincs befejezve, de a kosár törölve lett.");
  saveCartItems([]);
  updateCartDisplay();
  renderCartPage();
}

window.addEventListener("DOMContentLoaded", () => {
  updateCartDisplay();
  renderCartPage();
  setupAuthToggle();

  const cartBox = document.querySelector(".cart-box");
  if (cartBox) {
    cartBox.addEventListener("click", () => {
      window.location.href = "kosar.html";
    });
  }

  const checkoutBtn = document.querySelector("#checkout-btn");
  if (checkoutBtn) {
    checkoutBtn.addEventListener("click", checkout);
  }

  const clearBtn = document.querySelector("#clear-cart-btn");
  if (clearBtn) {
    clearBtn.addEventListener("click", clearCart);
  }
});

const elements = document.querySelectorAll(".hidden");

window.addEventListener("scroll", () => {
  elements.forEach(el => {
    const rect = el.getBoundingClientRect();
    if (rect.top < window.innerHeight - 50) {
      el.classList.add("show");
    }
  });
});

// --- Search handling: redirect on Enter and filter results on termekek.html ---
function setupSearchInputs() {
  const searches = document.querySelectorAll('input.search');
  searches.forEach(input => {
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        const q = input.value.trim();
        if (!q) return;
        window.location.href = `termekek.html?search=${encodeURIComponent(q)}`;
      }
      if (e.key === 'Escape') {
        clearSearch();
      }
    });
  });
}

function clearSearch() {
  const searches = document.querySelectorAll('input.search');
  searches.forEach(input => input.value = '');

  const productRows = document.querySelectorAll('.product-row');
  if (productRows.length) {
    productRows.forEach(row => row.style.display = '');
  } else {
    document.querySelectorAll('.card').forEach(card => card.style.display = '');
  }

  const info = document.querySelector('.search-info');
  if (info) info.remove();

  const url = new URL(window.location);
  if (url.searchParams.has('search')) {
    url.searchParams.delete('search');
    window.history.replaceState({}, document.title, url.pathname + (url.search ? '?' + url.search : '') + url.hash);
  }
}

function applySearchFromQuery() {
  const params = new URLSearchParams(window.location.search);
  const q = params.get('search');
  if (!q) return;
  const query = q.toLowerCase();

  const searches = document.querySelectorAll('input.search');
  searches.forEach(input => input.value = q);

  let matched = 0;

  // Try product rows (termekek.html)
  const productRows = document.querySelectorAll('.product-row');
  if (productRows.length) {
    productRows.forEach(row => {
      const titleEl = row.querySelector('h3');
      const title = titleEl ? titleEl.innerText.toLowerCase() : '';
      if (title.includes(query)) {
        row.style.display = '';
        matched++;
      } else {
        row.style.display = 'none';
      }
    });
  } else {
    // Fallback to cards (index.html and others)
    const cards = document.querySelectorAll('.card');
    cards.forEach(card => {
      const titleEl = card.querySelector('h3');
      const title = titleEl ? titleEl.innerText.toLowerCase() : '';
      if (title.includes(query)) {
        card.style.display = '';
        matched++;
      } else {
        card.style.display = 'none';
      }
    });
  }

  let info = document.querySelector('.search-info');
  if (!info) {
    info = document.createElement('div');
    info.className = 'search-info';
    info.style.padding = '10px';
    info.style.background = '#f7f7f7';
    info.style.margin = '10px';
    info.style.borderRadius = '4px';
    info.style.display = 'flex';
    info.style.alignItems = 'center';
    info.style.gap = '10px';
    const container = document.querySelector('.products') || document.querySelector('.products-list-vertical') || document.body;
    container.parentNode.insertBefore(info, container);
  }

  info.textContent = `Keresés: "${q}" — találat: ${matched}`;
  const clearBtn = document.createElement('button');
  clearBtn.className = 'clear-search-btn';
  clearBtn.textContent = 'Keresés visszavonása';
  clearBtn.style.padding = '6px 10px';
  clearBtn.style.border = '1px solid #94a3b8';
  clearBtn.style.borderRadius = '6px';
  clearBtn.style.background = '#fff';
  clearBtn.style.fontSize = '0.85rem';
  clearBtn.style.color = '#333';
  clearBtn.style.cursor = 'pointer';
  clearBtn.addEventListener('click', clearSearch);
  info.appendChild(clearBtn);
}

window.addEventListener('DOMContentLoaded', () => {
  setupSearchInputs();
  applySearchFromQuery();
});
