import pathlib
import re

replacements = [
    ('Â', ''),
    ('đź›’', '🛒'),
    ('Ă¡', 'á'), ('Ă©', 'é'), ('Ă­', 'í'), ('Ă³', 'ó'), ('Ă¶', 'ö'), ('Ăş', 'ú'), ('Ăű', 'ű'),
    ('Ă¸', 'ö'), ('ĂŠ', 'É'), ('Ă‰', 'É'), ('Ă˝', 'Ý'), ('Ăš', 'Ú'), ('Ă–', 'Ö'),
    ('Ă’', '’'), ('ĂĽ', 'ű'), ('Ă‚', 'Á'), ('Ă‘', 'Ó'), ('Ă„', 'Ä'),
    ('â„˘', '™'), ('â€“', '–'), ('â€”', '—'), ('â€ž', '„'), ('â€œ', '“'), ('â€', '”'),
    ('FĹ‘oldal', 'Főoldal'), ('MinĹ‘sĂ©gi', 'Minőségi'), ('mĹ±k', 'műk'),
    ('HĹ‘', 'ő'), ('Ĺ±', 'ű'), ('HĹ°', 'ő'),
    ('KosĂˇr', 'Kosár'), ('RegisztrĂˇciĂł', 'Regisztráció'), ('BelĂ©pĂ©s', 'Belépés'),
    ('KeresĂ©s', 'Keresés'), ('TermĂ©kek', 'Termékek'),
    ('Kattints a kosĂˇr', 'Kattints a kosár'), ('A kosarad ĂĽres', 'A kosarad üres'),
    ('Ă–sszesen', 'Összesen'), ('KosĂˇr ĂĽrĂ­tĂ©se', 'Kosár ürítése'), ('FizetĂ©s', 'Fizetés'),
    ('EcoBubbleâ„˘', 'EcoBubble™'), ('MĂ©g', 'Még'), ('tĂ¶kĂ©letes', 'tökéletes'),
    ('szĂ¡llĂ­tĂ¡s', 'szállítás'), ('vĂ­ztakarĂ©kos', 'víztakarékos'), ('vĂ­zben', 'vízben'),
    ('vĂ¡lasztĂ¡s', 'választás'), ('kĂ¶zĂĽl', 'közül'), ('kĂ¶zĂľl', 'közül'),
    ('Ă­', 'í'), ('Ă°', '°'), ('FizetĂ©s', 'Fizetés'), ('KosĂˇrba', 'Kosárba'),
    ('RegisztrĂˇciĂł', 'Regisztráció'), ('BelĂ©pĂ©s', 'Belépés'),
]

path = pathlib.Path('.')
files = list(path.glob('*.html'))
for file in files:
    text = file.read_text(encoding='utf-8', errors='replace')
    orig = text
    for old, new in replacements:
        text = text.replace(old, new)
    if text != orig:
        file.write_text(text, encoding='utf-8')
        print('Updated', file)

pattern = re.compile(r'(?:Ă[^\s<>]*|Ĺ[^\s<>]*|â[^\s<>]*|đ[^\s<>]*|ð[^\s<>]*)')
for file in files:
    text = file.read_text(encoding='utf-8', errors='replace')
    found = set(pattern.findall(text))
    if found:
        print('Remaining', file, found)
